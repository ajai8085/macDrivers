#!/usr/bin/env python2

import sys

try:
    from Quartz import CGGetOnlineDisplayList, CGDisplayIsBuiltin, CGDisplayIsMain, CGDisplayIsAsleep, CGDisplayRotation, CGDisplayBounds
    from Quartz import CGDisplayMirrorsDisplay, CGDisplayIsInMirrorSet
    from Quartz import CGDisplayCopyDisplayMode, CGDisplayModeRelease, CGDisplayModeGetRefreshRate, CGDisplayModeGetWidth, CGDisplayModeGetHeight
    from Quartz import CGDisplayModeGetPixelWidth, CGDisplayModeGetPixelHeight
except ImportError as e:
    print("Module import error: {}".format(e))
    sys.exit()

class DisplayDetails(object):
    def __init__(self, screen_id):
        self.__id = screen_id
        self.__is_builtin = bool(CGDisplayIsBuiltin(screen_id))
        self.__is_main = bool(CGDisplayIsMain(screen_id))
        self.__is_a_sleep = bool(CGDisplayIsAsleep(screen_id))
        self.__rotation = int(CGDisplayRotation(screen_id))
        self.__mirror_set = self.__check_mirror_mode(screen_id)
        self.__position = self.__get_screen_position(screen_id)
        self.__mode = self.__get_display_mode(screen_id)

    @property
    def id(self):
        return self.__id

    @property
    def is_a_sleep(self):
        return self.__is_a_sleep

    @property
    def is_builtin(self):
        return self.__is_builtin

    @property
    def is_main(self):
        return self.__is_main

    @property
    def mirror_set(self):
        return self.__mirror_set

    @property
    def mode(self):
        return self.__mode

    @property
    def rotation(self):
        return self.__rotation

    @property
    def position(self):
        return self.__position

    def __get_flags(self):
        flags = []

        if self.is_main:
            flags.append("MAIN")

        is_in_mirror_set, mirrored_id = self.mirror_set
        if is_in_mirror_set:
            flags.append("MIRROR: {}".format(mirrored_id if mirrored_id!=0 else "BASE"))

        if self.is_a_sleep:
            flags.append("SLEEP")

        if self.is_builtin:
            flags.append("BUILT-IN")

        return flags

    def __get_display_mode(self, screen_id):
        display_mode = CGDisplayCopyDisplayMode(screen_id)
        refresh_rate = round(CGDisplayModeGetRefreshRate(display_mode), 2)
        width = CGDisplayModeGetWidth(display_mode)
        height = CGDisplayModeGetHeight(display_mode)
        pixel_width = CGDisplayModeGetPixelWidth(display_mode)
        pixel_height = CGDisplayModeGetPixelHeight(display_mode)
        CGDisplayModeRelease(display_mode)
        is_virtual_mode = (width != pixel_width or height != pixel_height)
        return width, height, pixel_width, pixel_height, refresh_rate, is_virtual_mode

    def __check_mirror_mode(self, screen_id):
        is_in_mirror_set = bool(CGDisplayIsInMirrorSet(screen_id))
        mirrored_display = CGDisplayMirrorsDisplay(screen_id)
        return is_in_mirror_set, mirrored_display

    def __get_screen_position(self, screen_id):
        screen_bounds = CGDisplayBounds(screen_id)
        return screen_bounds.origin

    def __str__(self):
        display_text_representation = []
        width, height, pixel_width, pixel_height, refresh_rate, is_virtual_mode = self.mode
        display_text_representation.append("Display ID: {} Flags: {}".format(self.__id, self.__get_flags()))

        mode_str = "Mode: {}x{}@{}".format(pixel_width, pixel_height, refresh_rate)
        if is_virtual_mode:
            mode_str += " (PHYSICAL), {}x{} (VIRTUAL)".format(width, height)
        display_text_representation.append(mode_str)

        display_text_representation.append("Position: ({},{}) Rotation: {}".format(int(self.position.x), int(self.position.y), self.rotation))
        return "\n".join(display_text_representation)


def print_displays_layout():
    max_displays_amount = 20
    error, online_displays_ids, displays_count = CGGetOnlineDisplayList(max_displays_amount, None, None)

    if error != 0:
        print("Cannot get online displays")
        return

    print("Online displays count: {}\n".format(displays_count))
    for display_id in online_displays_ids:
        display_details = DisplayDetails(display_id)
        print("{}\n".format(display_details))


if __name__ == "__main__":
    print_displays_layout()
