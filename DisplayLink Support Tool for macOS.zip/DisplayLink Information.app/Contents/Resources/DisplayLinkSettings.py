#!/usr/bin/python

import os
import sys
import xml.etree.ElementTree as ElementTree


class DLXmlEngine(object):
    def __init__(self, xml_path):
        self.tree = None
        self.path = os.path.abspath(xml_path)
        if (not os.path.exists(self.path)) or not os.access(self.path, os.W_OK | os.R_OK):
            raise RuntimeError("XML file: %s not found or not accessible\n" % self.path)
        try:
            self.tree = ElementTree.parse(self.path)
            self.root = self.tree.getroot()
        except Exception: # pylint: disable=W0703
            self.root = ElementTree.Element(r"DL_HIVE")
            self.tree = ElementTree.ElementTree(self.root)

        software = self.tree.find(self._xpath(r"HKEY_LOCAL_MACHINE\Software"))
        if software is not None:
            software.set("name", "Software")

    def __del__(self):
        if self.tree:
            self.tree.write(self.path)

    @staticmethod
    def _xpath(key, parts_to_strip=0):
        parts = key.split("\\")
        if parts_to_strip != 0:
            parts = parts[:-1*parts_to_strip]
        return "./" + "/".join(["node[@name='%s']" % part for part in parts])

    def add_key(self, key):
        parts = key.split("\\")
        current = self.root
        for part in parts:
            next_node = current.find("node[@name='%s']" % part)
            if next_node is None:
                node = ElementTree.Element("node")
                node.set("name", part)
                current.append(node)
                current = node
            else:
                current = next_node

    def remove_key(self, key):
        found = self.root.find(self._xpath(key))
        if found is not None:
            parent = self.root.find(self._xpath(key, 1))
            parent.remove(found)

    def add_value(self, key, value, payload):
        self.add_key(key)
        parent = self.root.find(self._xpath(key))
        if parent is not None:
            tag = ElementTree.Element("value")
            tag.set("name", value.strip('"'))
            tag.text = payload.strip('"')
            parent.append(tag)

    def remove_value(self, key, value):
        parent = self.root.find(self._xpath(key))
        if parent is None:
            return

        while True:
            found = parent.find("value[@name='%s']" % value.strip('"'))
            if found is None:
                break
            parent.remove(found)

    def replace_value(self, key, value, payload):
        self.remove_value(key, value)
        self.add_value(key, value, payload)


def set_logging(path, verbosity):
    dlxml = None
    dluaxml = None
    key_dl = r"HKEY_LOCAL_MACHINE\Software\DisplayLink"
    try:
        dlxml = DLXmlEngine(os.path.join(path, ".dl.xml"))
    except:
        sys.stderr.write("Opening .dl.xml at %s failed\n" % path)

    try:
        dluaxml = DLXmlEngine(os.path.join(path, ".dlua.xml"))
    except:
        sys.stderr.write("Opening .dlua.xml at %s failed\n" % path)

    if dlxml:
        dlxml.replace_value(key_dl + r"\Logger", "verbosity", verbosity)

    if dluaxml:
        dluaxml.replace_value(key_dl + r"\Logger", "verbosity", verbosity)

def main():

    set_logging(os.path.abspath(sys.argv[1]), sys.argv[2])

    return 0

if __name__ == "__main__":
    sys.exit(main())
